import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Minesweeper 
{
	public static class Minefield
	{
		String [][] field;
		int col, row;
		int fieldCount = 1;
		
		public Minefield(int row, int col)
		{
			String[][] field = new String[col + 2][row + 2];
			this.col = col;
			this.row = row;
			this.fieldCount = fieldCount;
		}
		
		public String calcMineDistances(Minefield curField, int colToSolve, int rowToSolve)
		{
			int numMines = 0;
			
			if (curField.field[colToSolve][rowToSolve].contentEquals("*"))
			{
				return "*";
			}
			
			if(curField.field[colToSolve-1][rowToSolve-1].contentEquals("*"))
			{
				numMines += 1;
			}
			
			if(curField.field[colToSolve-1][rowToSolve].contentEquals("*"))
			{
				numMines += 1;
			}
			
			if(curField.field[colToSolve-1][rowToSolve+1].contentEquals("*"))
			{
				numMines += 1;
			}
			
			//Middle
			if(curField.field[colToSolve][rowToSolve-1].contentEquals("*"))
			{
				numMines += 1;
			}
			if(curField.field[colToSolve][rowToSolve+1].contentEquals("*"))
			{
				numMines += 1;
			}
			
			//Bottom
			if(curField.field[colToSolve + 1][rowToSolve-1].contentEquals("*"))
			{
				numMines += 1;
			}
			
			if(curField.field[colToSolve + 1][rowToSolve].contentEquals("*"))
			{
				numMines += 1;
			}
			
			if(curField.field[colToSolve + 1][rowToSolve+1].contentEquals("*"))
			{
				numMines += 1;
			}
			
			return Integer.toString(numMines);
		}
		
		public void solveMinefield(Minefield curField)
		{
			for (int col = 1; col < curField.col - 1; col++)
			{
				for (int row = 1; row < curField.row - 1; row++)
				{
					System.out.println(calcMineDistances(curField, col + 1, row + 1));
				}
			}
		}
	}
	
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(new InputStreamReader(System.in));
		
		Minefield field = readArray(scanner);
		System.out.println("Field#: " + field.fieldCount);
		field.solveMinefield(field);
	}
	
	private static Minefield readArray(Scanner file)
	{
		int colSize = 0, rowSize = 0;
		while (file.hasNextInt())
		{
			colSize = file.nextInt();
			rowSize =  file.nextInt();
		}
		
		Minefield targField = new Minefield(colSize, rowSize);
		String[] lineScan = new String[colSize];
		String lineRead;
				
		for (int col = 1; col < targField.col - 1; col++)
		{
			lineScan[col] = file.next();
			for (int row = 1; row < targField.row - 1; row++)
			{
				lineRead = lineScan[col];
				targField.field[col][row] = Character.toString(lineRead.charAt(0));
			}
		}
		
		return targField;
	}
}
